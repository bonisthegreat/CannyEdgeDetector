Blocks :  sigma=0.8; tLow=0.005, tHigh=0.02
Lenna_noise:  sigma=2; tLow=0.01; tHigh = 0.1
Castle: sigma=0.2; tLow=0.001; tHigh=0.05


