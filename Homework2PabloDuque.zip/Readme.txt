Test picture: Signs
Sigma: 1
TLow: 0.08
THigh: 0.8
